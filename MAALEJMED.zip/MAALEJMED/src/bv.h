#ifndef BUREAUDEVOTE_H_INCLUDED
#define BUREAUDEVOTE_H_INCLUDED
#include <stdio.h>
#include <gtk/gtk.h>


typedef struct date
{
char jj;
char mm;
char aa;
}date;
typedef struct
{
char nom[50];
char prenom[50];
int  cin;
date ddn;
char login[50];
char mdp[50];
char role[50];
char sexe ;
char vote;
char nbv;
}utilisateur;
typedef struct 
{
	char vote[100];
	int nbvotes;
}nvote;
void statTVB(int *TVB, utilisateur U);
int nbe(char *l_bv,char *User,int t_nb[]);
void affichervote(char valeur[10],char afficher[10]);

typedef struct
{
	char idbv[10];
	char cebv[10];
	char cobv[10];
	char sabv[10] ;
	char idagbv[10];


}listebv;

listebv chercher (char *l_bv, char id[]);
int ajout_listebv(char *l_bv ,listebv bv);
int modifier_listebv(char *l_bv, listebv nv);
int supprimer_listebv(char *l_bv, char id[]);
void afficher(GtkWidget *liste);

#endif
