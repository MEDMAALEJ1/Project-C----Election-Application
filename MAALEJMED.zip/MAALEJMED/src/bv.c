#include<stdio.h>
#include "bv.h"
#include<string.h>
#include <gtk/gtk.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"


enum
{
    EIDBV,
    ECEBV,
    ECOBV,
    ESABV,
    EIDAGBV,
    COLUMNS,
};





//CHERCHER*******************************************************************************************
listebv chercher (char *l_bv, char id[])
{
	int trouver=0;
	listebv bv;
	FILE * f=fopen(l_bv, "r");
	if(f!=NULL)
	{
		while(trouver==0 && fscanf(f,"%s %s %s %s %s\n",bv.idbv,bv.cebv,bv.cobv,bv.sabv,bv.idagbv)!=EOF)
		{
			if(strcmp(bv.idbv,id)==0)
				trouver=1;
		}
	}
	fclose(f);
	if (trouver==0)
		strcpy(bv.idbv,"****");
	return bv;
}
//AJOUTER*************************************************************************************************
int ajout_listebv(char *l_bv ,listebv bv) 
{
	FILE * f=fopen(l_bv, "a");
	if (f!=NULL)
	{

		fprintf(f,"%s %s %s %s %s\n",bv.idbv,bv.cebv,bv.cobv,bv.sabv,bv.idagbv);
		fclose(f);
		return 1;
	}
	else 
		return 0;
}
//MODIFIER***********************************************************************************************
int modifier_listebv(char *l_bv, listebv nv)
{
	int trouver=0;
	listebv bv;
	FILE * f=fopen(l_bv, "r");
	FILE * f2=fopen("nv.txt", "a+");
	if(f!=NULL && f2!=NULL)
	{
		while(fscanf(f,"%s %s %s %s %s\n",bv.idbv,bv.cebv,bv.cobv,bv.sabv,bv.idagbv)!=EOF)
		{
			if(strcmp(bv.idbv,nv.idbv)==0)
			{
				fprintf(f2,"%s %s %s %s %s\n",nv.idbv,nv.cebv,nv.cobv,nv.sabv,nv.idagbv);
				trouver=1;
			}
			else 
				fprintf(f2,"%s %s %s %s %s\n",bv.idbv,bv.cebv,bv.cobv,bv.sabv,bv.idagbv);
		}
	}
	fclose(f);
	fclose(f2);
	remove(l_bv);
	rename("nv.txt", l_bv);
	return(trouver);
}
//SUPPRIMER*************************************************************************************
int supprimer_listebv(char *l_bv, char id[])
{
	int trouver=0;
	listebv bv;
	FILE * f=fopen(l_bv, "r");
	FILE * f2=fopen("nv.txt", "w");
	if(f!=NULL && f2!=NULL)
	{
		while (fscanf(f,"%s %s %s %s %s\n",bv.idbv,bv.cebv,bv.cobv,bv.sabv,bv.idagbv)!=EOF)
		{
			if(strcmp(bv.idbv,id)==0)
				trouver=1;
			else 
				fprintf(f2,"%s %s %s %s %s\n",bv.idbv,bv.cebv,bv.cobv,bv.sabv,bv.idagbv);
		}
	}
	fclose(f);
	fclose(f2);
	remove(l_bv);
	rename("nv.txt",l_bv);
	return trouver;
	
}
// AFFICHER**************************************************************************************************
void afficher(GtkWidget *liste)
{
    GtkCellRenderer *renderer; // afficheur de cellule (Cellule contient un texte, image, case à cocher)
    GtkTreeViewColumn *column; // visualisation des colonnes
    GtkTreeIter iter;          /**/
    GtkListStore *store;       // création du modèle de type liste

    char idbv[10];
    char cebv[10];
    char cobv[10];
    char sabv[10];
    char idagbv[10];
  
    store = NULL;
    listebv bv;

    FILE *f;

    store = gtk_tree_view_get_model(liste);
    if (store == NULL)
    {
        
renderer=gtk_cell_renderer_text_new();                                                               // cellule contenant du texte
        column = gtk_tree_view_column_new_with_attributes("Id Bureau de Vote", renderer, "text", EIDBV, NULL); // création d'une colonne avec du texte
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);                                             // associer la colonne à l'afficheur (GtkTreeView)

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Capacité des électeurs", renderer, "text", ECEBV, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Capacité des obsérvateurs", renderer, "text", ECOBV, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Numéro de la Salle", renderer, "text", ESABV, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Id Agent du BV", renderer, "text", EIDAGBV, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

        // La liste contient 5 colonnes de type chaine de caractères
    }
    store = gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
    f = fopen("l_bv.txt", "r");

    if (f == NULL)
    {
        return;
    }
    else
    {
        f = fopen("l_bv.txt", "a+");
        while (fscanf(f, "%s %s %s %s %s\n", bv.idbv, bv.cebv, bv.cobv, bv.sabv, bv.idagbv) != EOF)
        {
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter, EIDBV, bv.idbv, ECEBV, bv.cebv, ECOBV, bv.cobv, ESABV, bv.sabv, EIDAGBV, bv.idagbv,-1);
        }
        fclose(f);
        gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
        g_object_unref(store);
    }
}
//satistiques***************************************************
void statTVB(int *TVB, utilisateur U)
{
 
int nbvotes=0;
int nbvblanc=0;
FILE *f3=NULL;
f3=fopen("utilisateur.txt","r");
while(fscanf(f3,"%s %s %s %s %s %s %s %s %s %s %s %s\n",U.nom,U.prenom,U.cin,U.ddn.jj,U.ddn.mm,U.ddn.aa,U.login,U.mdp,U.role,U.sexe,U.vote,U.nbv)!=EOF)
{if(strcmp (U.vote,"0")==0)
     { *TVB=*TVB+1;}
     //nbvotes++;
      }

//printf("nombre de votes blancs %d",nbvblanc);
//*TVB=(nbvblanc/vote)*100;
//printf("le pourcentage de vote blanc est  %f",TVB);

fclose(f3);
}
void affichervote(char valeur[],char afficher[])
{
	strcpy(afficher,"nombre de votes blancs");
	strcat(afficher,valeur);
}

/*int nbe(char *l_bv,char *User,int t_nb[])
{
	utilisateur U;
        listebv bv;
	int i=0,taille=0,nb,n=0,t[50];
	    FILE *f=fopen("listebv.txt", "r");
	    FILE *f2 =fopen("user.txt", "r");

	if(f!=NULL && f2!=NULL)
	{
	while(fscanf(f2,"%s %s %s %s %s %s %s %s %s %s %s %s\n  ",U.nom,U.prenom,U.cin,U.ddn.jj,U.ddn.mm,U.ddn.aa,U.login,U.mdp,U.role,U.sexe,U.vote,U.nbv)!=EOF)
	{
	t[i]=U.nbv;
	i++;
	n++;
	}
	while(fscanf(f,"%s %s %s %s %s\n", bv.idbv,bv.cebv,bv.cobv,bv.sabv,bv.idagbv)!=EOF)
	{
	nb=0;
	for(i=0;i<n;i++)
	{
	if(t[i]==bv.idbv)
	nb++;
	}
	t_nb[taille]=nb;
	taille++;
	}
	fclose(f);
	fclose(f2);
	return(taille);
	}
}*/



