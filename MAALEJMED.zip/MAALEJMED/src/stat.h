#define BUREAUDEVOTE_H_INCLUDED
#include <stdio.h>
#include "bv.h"
typedef struct date
{
char jj;
char mm;
char aa;
}date;
typedef struct
{
char nom[50];
char prenom[50];
int  cin;
date ddn;
char login[50];
char mdp[50];
char role[50];
char sexe ;
char vote;
char nbv;
}utilisateur;
typedef struct 
{
	char vote[100];
	int nbvotes;
}nvote;
void statTVB(float *TVB, utilisateur U);
int nbe(char *l_bv,char *User,int t_nb[]);
void affichervote(char valeur[],char afficher[]);
