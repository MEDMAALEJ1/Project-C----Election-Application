#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "bv.h"


int choix , etatX=0, etat2=0;
int TVB;
void
on_baffecter_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
listebv bv;
int x;
GtkWidget *input1,*input2,*input3,*input4,*input5;
GtkWidget *fenetre_ajout;

input1=lookup_widget(button,"entry1");
input2=lookup_widget(button,"entry2");
input3=lookup_widget(button,"entry3");
input4=lookup_widget(button,"comboA");
input5=lookup_widget(button,"entry5");
strcpy(bv.idbv,gtk_entry_get_text(GTK_ENTRY(input1)));

strcpy(bv.cebv,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(bv.cobv,gtk_entry_get_text(GTK_ENTRY(input3)));

strcpy(bv.sabv,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input4)));

strcpy(bv.idagbv,gtk_entry_get_text(GTK_ENTRY(input5)));

if (etat2==1){
x=ajout_listebv("l_bv.txt",bv);
}
/*GtkWidget *objet_graphique;
GtkWidget *ListeBV;
GtkWidget *AjoutBV;
ListeBV=lookup_widget(objet_graphique,"AjoutBV");
gtk_widget_destroy(AjoutBV);
ListeBV=lookup_widget(objet_graphique,"ListeBV");
ListeBV=create_ListeBV();
gtk_widget_show(ListeBV);*/
	   

}


void
on_checkbA_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
etat2=1;
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview1,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	
    	GtkTreeIter iter;
    	gchar *idbv;
    	gchar *cebv;
    	gchar *cobv;
    	gchar *sabv;
    	gchar *idagbv;
    	listebv bv;
    	int id, x;	

    	GtkTreeModel *model;
	model = gtk_tree_view_get_model(treeview1);

    	if (gtk_tree_model_get_iter(model, &iter, path))
    	{
        	gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &idbv, 1, &cebv, 2, &cobv, 3, &sabv, 4, &idagbv, -1);
        	strcpy(bv.idbv, idbv);
        	strcpy(bv.cebv, cebv);
        	strcpy(bv.cobv, cobv);
        	strcpy(bv.sabv, sabv);
        	strcpy(bv.idagbv, idagbv);

        /*supprimer_listebv("l_bv.txt",bv.idbv);*/
        afficher(treeview1);
        }
}


void
on_bchercher_clicked                   (GtkWidget      *objet,
                                        gpointer         user_data)
{

char ch1[20];
listebv bv;
  GtkWidget *entry6;
  GtkWidget *label42;
  GtkWidget *label43;
  GtkWidget *label44;
  GtkWidget *label45;
  GtkWidget *label46;
  GtkWidget *label48;

label42=lookup_widget(objet,"label42");
label43=lookup_widget(objet,"label43");
label44=lookup_widget(objet,"label44");
label45=lookup_widget(objet,"label45");
label46=lookup_widget(objet,"label46");

entry6=lookup_widget(objet,"entry6");
strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(entry6)));
bv=chercher ("l_bv.txt",ch1);
gtk_label_set_text(GTK_LABEL(label42),bv.idbv);
gtk_label_set_text(GTK_LABEL(label43),bv.cebv);
gtk_label_set_text(GTK_LABEL(label44),bv.cobv);
gtk_label_set_text(GTK_LABEL(label45),bv.sabv);
gtk_label_set_text(GTK_LABEL(label46),bv.idagbv);
if ( strcmp(bv.idbv,ch1)!=0)
{label48=lookup_widget(objet,"label48");
gtk_widget_show(label48);
}






	/*GtkWidget *entrych;
	GtkWidget *ListeBV;
	GtkWidget *fenetre_2;
	entrych=lookup_widget(button,"entry6");
	fenetre_2 = lookup_widget(button, "ListeBV");
	ListeBV=lookup_widget(fenetre_2, "treeview1");
	chercher(ListeBV,gtk_entry_get_text(GTK_ENTRY(entrych)));*/

}


void
on_bajouter_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)

{
   GtkWidget *ListeBV;
   GtkWidget *AjoutBV;
   AjoutBV=lookup_widget(objet_graphique,"ListeBV");
   gtk_widget_destroy(ListeBV);
   AjoutBV=lookup_widget(objet_graphique,"AjoutBV");
   AjoutBV=create_AjoutBV();
   gtk_widget_show(AjoutBV);
}


void
on_bmod_clicked                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
   GtkWidget *ListeBV;
   GtkWidget *modificationBV;
   modificationBV=lookup_widget(objet_graphique,"ListeBV");
   gtk_widget_destroy(ListeBV);
   modificationBV=lookup_widget(objet_graphique,"modificationBV");
   modificationBV=create_modificationBV();
   gtk_widget_show(modificationBV);
}


void
on_bsupp_clicked                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
   GtkWidget *ListeBV;
   GtkWidget *SupprimerBV;
   SupprimerBV=lookup_widget(objet_graphique,"ListeBV");
   gtk_widget_destroy(ListeBV);
   SupprimerBV=lookup_widget(objet_graphique,"SupprimerBV");
   SupprimerBV=create_SupprimerBV();
   gtk_widget_show(SupprimerBV);
}

void
on_bannulerm_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	
	/*GtkWidget *ListeBV;
	GtkWidget *modificationBV;
	modificationBV=lookup_widget(objet_graphique,"modificationBV");
	gtk_widget_destroy(modificationBV);
	ListeBV=create_ListeBV();
	gtk_widget_show(ListeBV);*/
	GtkWidget *ListeBV, *modificationBV;
	modificationBV=lookup_widget(objet_graphique,"modificationBV");  
	gtk_widget_destroy(modificationBV);
	ListeBV=create_ListeBV();
//gtk_widget_show(ListeBV);
}

void
on_bannuler_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *ListeBV, *AjoutBV;
	AjoutBV=lookup_widget(objet_graphique,"AjoutBV");  
	gtk_widget_destroy(AjoutBV);
	ListeBV=create_ListeBV();
}

void
on_baffecterm_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
listebv bv;
int x;
GtkWidget *input1,*input2,*input3,*input4,*input5;
GtkWidget *fenetre_ajout;

input1=lookup_widget(button,"entry7");
input2=lookup_widget(button,"entry8");
input3=lookup_widget(button,"entry9");
input4=lookup_widget(button,"comboM");
input5=lookup_widget(button,"entry10");
strcpy(bv.idbv,gtk_entry_get_text(GTK_ENTRY(input1)));

strcpy(bv.cebv,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(bv.cobv,gtk_entry_get_text(GTK_ENTRY(input3)));

strcpy(bv.sabv,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input4)));

strcpy(bv.idagbv,gtk_entry_get_text(GTK_ENTRY(input5)));
if(etatX==1)
{

x=modifier_listebv("l_bv.txt",bv);

	   }

}


void
on_checkbM_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
etatX=1;

}


void
on_non_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
	choix=0;
}


void
on_oui_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
	choix=1;
}


void
on_bactualiser_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{
	GtkWidget *windowact;
	GtkWidget *fenetre_2;
	GtkWidget *fenetre_1;
	fenetre_1=lookup_widget(button,"ListeBV");
	gtk_widget_hide(fenetre_1);
	fenetre_2=create_ListeBV();
	gtk_widget_show(fenetre_2);
	windowact=lookup_widget(fenetre_2,"treeview1");
	afficher(windowact);
}





void
on_baffecterS_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data)
{
	char ch[20] ;
	GtkWidget *entry11;
	entry11=lookup_widget(objet,"entry11");
	strcpy(ch,gtk_entry_get_text(GTK_ENTRY(entry11)));
	if (choix==1)
	supprimer_listebv("l_bv.txt",ch);
	

}


void
on_stat_clicked                        (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
	//char var[10];
	
	GtkWidget *input;
	GtkWidget *output;
	utilisateur U;
	char valeur[10];
	char afficher[10];
	GtkWidget *Statistiques;
	Statistiques=lookup_widget(objet_graphique,"Statistiques");
	Statistiques=create_Statistiques();
	gtk_widget_show(Statistiques);
	statTVB(&TVB,U);
	sprintf(valeur,"%d",TVB);
	output=lookup_widget(Statistiques,"label50");
	affichervote(valeur,afficher);
	gtk_label_set_text(GTK_LABEL(output),afficher);
}

