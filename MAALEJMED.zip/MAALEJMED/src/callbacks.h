#include <gtk/gtk.h>


void
on_baffecter_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_checkbA_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview1,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_bchercher_clicked                   (GtkWidget         *objet,
                                        gpointer         user_data);

void
on_bajouter_clicked                    (GtkWidget        *button,
                                        gpointer         user_data);

void
on_bmod_clicked                        (GtkWidget        *button,
                                        gpointer         user_data);

void
on_bsupp_clicked                       (GtkWidget         *button,
                                        gpointer         user_data);

void
on_bactualiser_clicked                 (GtkWidget        *button,
                                        gpointer         user_data);

void
on_bannulerm_clicked                   (GtkWidget        *objet_graphique,
                                        gpointer         user_data);

void
on_baffecterm_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_checkbM_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_non_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_oui_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_bactualiser_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_bannuler_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_baffecterS_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_stat_clicked                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
