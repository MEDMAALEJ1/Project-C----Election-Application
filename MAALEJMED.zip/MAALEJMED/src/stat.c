#include<stdio.h>
#include<string.h>
#include "stat.h"
#include "bv.h"
#include "stat.h"

void statTVB(float *TVB, utilisateur U)
{
 
int nbvotes=0;
int nbvblanc=0;
FILE *f3=NULL;
f3=fopen("utilisateur.txt","r");
while(fscanf(f3,"%s %s %s %s %s %s %s %s %s %s %s %s  ",U.nom,U.prenom,U.cin,U.ddn.jj,U.ddn.mm,U.ddn.aa,U.login,U.mdp,U.role,U.sexe,U.vote,U.nbv)!=EOF)
{if(strcmp (U.vote,"0")==0)
     { *TVB=*TVB+1;}
     //nbvotes++;
      }

//printf("nombre de votes blancs %d",nbvblanc);
//*TVB=(nbvblanc/vote)*100;
//printf("le pourcentage de vote blanc est  %f",TVB);

fclose(f3);
}
void affichervote(char valeur[],char afficher[])
{
	strcpy(afficher,"nombre de votes blancs");
	strcat(afficher,valeur);
}

/*int nbe(char *l_bv,char *User,int t_nb[])
{
	utilisateur U;
        listebv bv;
	int i=0,taille=0,nb,n=0,t[50];
	    FILE *f=fopen("listebv.txt", "r");
	    FILE *f2 =fopen("user.txt", "r");

	if(f!=NULL && f2!=NULL)
	{
	while(fscanf(f2,"%s %s %s %s %s %s %s %s %s %s %s %s\n  ",U.nom,U.prenom,U.cin,U.ddn.jj,U.ddn.mm,U.ddn.aa,U.login,U.mdp,U.role,U.sexe,U.vote,U.nbv)!=EOF)
	{
	t[i]=U.nbv;
	i++;
	n++;
	}
	while(fscanf(f,"%s %s %s %s %s\n", bv.idbv,bv.cebv,bv.cobv,bv.sabv,bv.idagbv)!=EOF)
	{
	nb=0;
	for(i=0;i<n;i++)
	{
	if(t[i]==bv.idbv)
	nb++;
	}
	t_nb[taille]=nb;
	taille++;
	}
	fclose(f);
	fclose(f2);
	return(taille);
	}
}*/
